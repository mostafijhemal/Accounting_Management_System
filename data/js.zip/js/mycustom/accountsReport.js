/*	
	window Open
		ledgerR = window.open('ledgerR', '_blank', 'menubar=1, scrollbars=1');
	    ledgerR.document.write(data);
	    ledgerR.stop(); 
	Site Url use for all Url set
	var site_url = $('#site_url').val();
*/

$(document).on('change', '#financial_year', function(){
	var financial_year 	= $(this).val();

	var arraFytYear 	=  financial_year.split(",");
	$('#from_date').val(arraFytYear[0]);
	$('#to_date').val(arraFytYear[1]);
});



//  Head Lavle Change Start
	function getLevel2(accountId){
		if(accountId == ''){
			$("#hL2_account_id, #hL3_account_id, #hL4_account_id, #hL5_account_id, #hL6_account_id, #hL7_account_id, #hL8_account_id").html('');
			return false;
		}
		var site_url = $('#site_url').val();

		$.ajax({
	        url 	: site_url + 'accReport/getChildHeadByParentHead',
	        type 	: "POST",
			data 	: {account_id:accountId},
			dataType: 'json',
	        success : function (data) {		
				$("#hL2_account_id, #hL3_account_id, #hL4_account_id, #hL5_account_id, #hL6_account_id, #hL7_account_id, #hL8_account_id").html(''); //reset child options
				$("#hL2_account_id").append("<option value=''>Select Level 2</option>");
				$.each(data, function(key, value){
			      var option = '<option value="'+value.account_id+'">'+value.account_name+' - '+value.account_id+'</option>';
			      $('#hL2_account_id').append(option);      
			    });
	        }
	    });
	}
	function getLevel3(accountId){
		if(accountId == ''){
			$("#hL3_account_id, #hL4_account_id, #hL5_account_id, #hL6_account_id, #hL7_account_id, #hL8_account_id").html('');
			return false;
		}
		var site_url = $('#site_url').val();

		$.ajax({
	        url 	: site_url + 'accReport/getChildHeadByParentHead',
	        type 	: "POST",
			data 	: {account_id:accountId},
			dataType: 'json',
	        success : function (data) {		
				$("#hL3_account_id, #hL4_account_id, #hL5_account_id, #hL6_account_id, #hL7_account_id, #hL8_account_id").html(''); //reset child options
				$("#hL3_account_id").append("<option value=''>Select Level 3</option>");
				$.each(data, function(key, value){
			      var option = '<option value="'+value.account_id+'">'+value.account_name+' - '+value.account_id+'</option>';
			      $('#hL3_account_id').append(option);      
			    });
	        }
	    });
	}
	function getLevel4(accountId){
		if(accountId == ''){
			$("#hL4_account_id, #hL5_account_id, #hL6_account_id, #hL7_account_id, #hL8_account_id").html('');
			return false;
		}
		var site_url = $('#site_url').val();

		$.ajax({
	        url 	: site_url + 'accReport/getChildHeadByParentHead',
	        type 	: "POST",
			data 	: {account_id:accountId},
			dataType: 'json',
	        success : function (data) {		
				$("#hL4_account_id, #hL5_account_id, #hL6_account_id, #hL7_account_id, #hL8_account_id").html(''); //reset child options
				$("#hL4_account_id").append("<option value=''>Select Level 4</option>");
				$.each(data, function(key, value){
			      var option = '<option value="'+value.account_id+'">'+value.account_name+' - '+value.account_id+'</option>';
			      $('#hL4_account_id').append(option);      
			    });
	        }
	    });
	}
	function getLevel5(accountId){
		if(accountId == ''){
			$("#hL5_account_id, #hL6_account_id, #hL7_account_id, #hL8_account_id").html('');
			return false;
		}
		var site_url = $('#site_url').val();

		$.ajax({
	        url 	: site_url + 'accReport/getChildHeadByParentHead',
	        type 	: "POST",
			data 	: {account_id:accountId},
			dataType: 'json',
	        success : function (data) {		
				$("#hL5_account_id, #hL6_account_id, #hL7_account_id, #hL8_account_id").html(''); //reset child options
				$("#hL5_account_id").append("<option value=''>Select Level 5</option>");
				$.each(data, function(key, value){
			      var option = '<option value="'+value.account_id+'">'+value.account_name+' - '+value.account_id+'</option>';
			      $('#hL5_account_id').append(option);      
			    });
	        }
	    });
	}
	function getLevel6(accountId){
		if(accountId == ''){
			$("#hL6_account_id, #hL7_account_id, #hL8_account_id").html('');
			return false;
		}
		var site_url = $('#site_url').val();

		$.ajax({
	        url 	: site_url + 'accReport/getChildHeadByParentHead',
	        type 	: "POST",
			data 	: {account_id:accountId},
			dataType: 'json',
	        success : function (data) {		
				$("#hL6_account_id, #hL7_account_id, #hL8_account_id").html(''); //reset child options
				$("#hL6_account_id").append("<option value=''>Select Level 6</option>");
				$.each(data, function(key, value){
			      var option = '<option value="'+value.account_id+'">'+value.account_name+' - '+value.account_id+'</option>';
			      $('#hL6_account_id').append(option);      
			    });
	        }
	    });
	}
	function getLevel7(accountId){
		if(accountId == ''){
			$("#hL7_account_id, #hL8_account_id").html('');
			return false;
		}
		var site_url = $('#site_url').val();

		$.ajax({
	        url 	: site_url + 'accReport/getChildHeadByParentHead',
	        type 	: "POST",
			data 	: {account_id:accountId},
			dataType: 'json',
	        success : function (data) {		
				$("#hL7_account_id, #hL8_account_id").html(''); //reset child options
				$("#hL7_account_id").append("<option value=''>Select Level 7</option>");
				$.each(data, function(key, value){
			      var option = '<option value="'+value.account_id+'">'+value.account_name+' - '+value.account_id+'</option>';
			      $('#hL7_account_id').append(option);      
			    });
	        }
	    });
	}
	function getLevel8(accountId){
		if(accountId == ''){
			$("#hL8_account_id").html('');
			return false;
		}
		var site_url = $('#site_url').val();

		$.ajax({
	        url 	: site_url + 'accReport/getChildHeadByParentHead',
	        type 	: "POST",
			data 	: {account_id:accountId},
			dataType: 'json',
	        success : function (data) {		
				$("#hL8_account_id").html(''); //reset child options
				$("#hL8_account_id").append("<option value=''>Select Level 8</option>");
				$.each(data, function(key, value){
			      var option = '<option value="'+value.account_id+'">'+value.account_name+' - '+value.account_id+'</option>';
			      $('#hL8_account_id').append(option);      
			    });
	        }
	    });
	}
//  Head Lavle Change End


$(document).on('focus', 'input[type=text]', function(){
	$('button').attr('disabled', 'disabled');
});

$(document).on('blur', 'input[type=text]', function(){
	$('button').removeAttr('disabled');
});

// Chart of accounts Report
function chartOfAccountsReport() {
	site_url = $('#site_url').val();
	window.open(site_url+ 'accReport/chartOfAccountsReport', '_blank');
}

// voucher Report 1709130001
function voucherReport() {
	var voucher_id 		= $('#voucher_id').val();
	if(voucher_id == '') {
		alert('The Voucher ID field is required');
		$('#voucher_id').focus();
		return false;
	}
	var financial_year 	= $('#financial_year').val();
	
	site_url = $('#site_url').val();
	$.ajax({
        url 	: site_url + 'accReport/getVoucherType',
        type 	: "POST",
        data 	: {voucher_id:voucher_id, financial_year:financial_year},
        dataType: 'html',
        success : function (data) {
            window.open(site_url+ 'accReport/voucher/'+data+'/'+voucher_id, '_blank');
            console.log('Ok');
        }
    });
	
}

// All voucher list Report 
function allVoucherListReport() {
	var from_date 	= $('#from_date').val();
	var to_date 	= $('#to_date').val();
	
	site_url = $('#site_url').val();

	window.open(site_url+ 'accReport/allVoucherList?from_date='+from_date+'&to_date='+to_date, '_blank');
}

// voucher list Report 
function voucherListReport() {
	var voucher_type 		= $('#voucher_type').val();
	if(voucher_type == '') {
		alert('The Voucher Type field is required');
		$('#voucher_type').focus();
		return false;
	}
	var from_date 	= $('#from_date').val();
	var to_date 	= $('#to_date').val();
	
	site_url = $('#site_url').val();

	window.open(site_url+ 'accReport/voucherList?voucher_type='+voucher_type+'&from_date='+from_date+'&to_date='+to_date, '_blank');
}

// voucher list Report By Analysis Code
function voucherListByAnCodeReport() {
	var infoTable = $('#infoTable').val();
	if(infoTable == '') {
		alert('The Select Analysis Type field is required');
		$('#infoTable').focus();
		return false;
	}

	var analysis_code = $('#analysis_code').val();
	if(analysis_code == '') {
		alert('The Analysis Code field is required');
		$('#analysis_code').focus();
		return false;
	}

	var table_auto_id 	= $('#table_auto_id').val();

	var from_date 	= $('#from_date').val();
	var to_date 	= $('#to_date').val();
	
	site_url = $('#site_url').val();

	window.open(site_url+ 'accReport/voucherListByAnalysisCode?tname='+infoTable+'&auid='+table_auto_id+'&analysis_code='+analysis_code+'&from_date='+from_date+'&to_date='+to_date, '_blank');
}

// check Analysis Code is Exist
$(document).on('blur', '#analysis_code', function(){
	var thisElement 	= $(this);
	var analysis_code 	= thisElement.val();

	var infoTable 		= $('#infoTable').val();
	if(infoTable == '') {
		alert('The Select Analysis Type field is required');
		$('#infoTable').focus();
		return false;
	}
	var arraytype 	  	= infoTable.split(' ');
	site_url = $('#site_url').val();
	$('#table_auto_id').val('');

	$.ajax( {
		url 	: site_url+'accVoucher/checkEnalisisCodeIsExist',
		type 	: "POST",
		data 	: {table:arraytype[0], encode:analysis_code},
		dataType: "json",
		success : function(data){
			if(data == ''){
				alert('Analysis Code doesn\'t match with information table...');
				thisElement.val('').focus();
				return false;
			}  else {
				$('#table_auto_id').val(data.auto_id);
			}
		},
      	error: function (xhr, ajaxOptions, thrownError) {
        	alert('Something is Wrong...');
			return false;
        }
	});
});

// ledger Report 
function ledgerReport(argument) {
	var account_head = $('#account_head').val();
	if(account_head == '') {
		alert('The Ledger Head field is required');
		$('#account_head').focus();
		return false;
	}
	var arrayHead 	= account_head.split(' ');
	var lastIndex  	= (arrayHead.length - 1);
	var accountId  	= arrayHead[lastIndex];

	site_url 		= $('#site_url').val();

	$.ajax( {
		url 	: site_url+'accVoucher/accountHeadIsExistAndEnalisisCodeRequired',
		type 	: "POST",
		data 	: {account_id:accountId},
		dataType: "json",
		success : function(data){
			if(data != null){
				var from_date 	= $('#from_date').val();
				var to_date 	= $('#to_date').val();
				window.open(site_url+ 'accReport/ledgerReport?account_id='+accountId+'&from_date='+from_date+'&to_date='+to_date, '_blank');
			} else {
				alert('Data Not Match with Chart of Accounts...');
				$('#account_head').val('').focus();
				return false;
			}
		},
      	error: function (xhr, ajaxOptions, thrownError) {
        	alert('Something is Wrong...');
			return false;
        }
	});
}

//Day Book report
function dayBookReport(){	
	var from_date 	= $('#from_date').val();
	var to_date 	= $('#to_date').val();
	
	site_url = $('#site_url').val();

	window.open(site_url+ 'accReport/dayBookReport?from_date='+from_date+'&to_date='+to_date, '_blank');
}

//Group Ledger Report

function groupLedgerReport(){	
	var hL1_id 	= $('#hL1_account_id').val();
	if(hL1_id == '') {
		alert('The Head Level 1 field is required');
		$('#hL1_account_id').focus();
		return false;
	}
	var hL2_id 	= $('#hL2_account_id').val();
	var hL3_id 	= $('#hL3_account_id').val();
	var hL4_id 	= $('#hL4_account_id').val();
	var hL5_id 	= $('#hL5_account_id').val();
	var hL6_id 	= $('#hL6_account_id').val();
	var hL7_id 	= $('#hL7_account_id').val();
	var hL8_id 	= $('#hL8_account_id').val();

	var from_date 	= $('#from_date').val();
	var to_date 	= $('#to_date').val();
	
	site_url = $('#site_url').val();

	window.open(site_url+ 'accReport/ledgerGroupReport?from_date='+from_date+'&to_date='+to_date+'&hL1_id='+hL1_id+'&hL2_id='+hL2_id+'&hL3_id='+hL3_id+'&hL4_id='+hL4_id+'&hL5_id='+hL5_id+'&hL6_id='+hL6_id+'&hL7_id='+hL7_id+'&hL8_id='+hL8_id, '_blank');
}

// Income Expend Report
function incomeExpendReport(){
	var from_date 	= $('#from_date').val();
	var to_date 	= $('#to_date').val();
	
	site_url = $('#site_url').val();

	window.open(site_url+ 'accReport/incomeExpendReport?from_date='+from_date+'&to_date='+to_date, '_blank');
}

// Income Statement Report
function incomeStatementReport(){
	var from_date 	= $('#from_date').val();
	var to_date 	= $('#to_date').val();
	
	site_url = $('#site_url').val();

	window.open(site_url+ 'accReport/incomeStatementReport?from_date='+from_date+'&to_date='+to_date, '_blank');
}


// Trial Balance Report
function trialBalanceReport() {
	var from_date 	= $('#from_date').val();
	var to_date 	= $('#to_date').val();
	
	site_url = $('#site_url').val();

	window.open(site_url+ 'accReport/trialBalanceReport?from_date='+from_date+'&to_date='+to_date, '_blank');
}


// Owners Equity Report
function ownersEquityReport(){
	var from_date 	= $('#from_date').val();
	var to_date 	= $('#to_date').val();
	
	site_url = $('#site_url').val();

	window.open(site_url+ 'accReport/ownersEquityReport?from_date='+from_date+'&to_date='+to_date, '_blank');
}


// Balance Sheet Report
function balanceSheetReport() {
	var from_date 	= $('#from_date').val();
	var to_date 	= $('#to_date').val();
	
	site_url = $('#site_url').val();

	window.open(site_url+ 'accReport/balanceSheetReport?from_date='+from_date+'&to_date='+to_date, '_blank');
}



